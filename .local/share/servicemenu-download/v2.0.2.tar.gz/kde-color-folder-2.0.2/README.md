# Color Folder

A KDE service menu for changing the color of specific folders, compatible with KDE4 and Plasma 5.

![Screen shot of Color Folder](colorfolder.png)

## Installation

```bash
chmod +x install.sh
./install.sh
```
